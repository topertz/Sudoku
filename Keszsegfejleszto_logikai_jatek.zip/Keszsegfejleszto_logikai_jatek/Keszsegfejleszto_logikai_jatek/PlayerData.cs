﻿
namespace Keszsegfejleszto_logikai_jatek
{
    public class PlayerData
    {
        public string LineCounter { get; set; }
        public string PlayerName { get; set; }
        public int CorrectAnswers { get; set; }
        public int HintCounter { get; set; }
        public string ElapsedTime { get; set; }
        public string BoardDifficulty { get; set; }
    }
}
